<?php
session_start();

$host='localhost'; $db='fish_rider'; $user='root'; $pass='';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
    ]);
} catch(Exception $e) {
    die("<div style='font-family:Arial;padding:30px'><h2>Database connection error</h2><p>Import <b>fish_rider.sql</b> in phpMyAdmin first.</p><pre>".htmlspecialchars($e->getMessage())."</pre></div>");
}

function h($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function redirect($url='index.php'){ header("Location: $url"); exit; }

if(isset($_GET['logout'])){ session_destroy(); redirect(); }

if(!isset($_SESSION['user'])){
    if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['login'])){
        $st=$pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
        $st->execute([trim($_POST['email'])]); $u=$st->fetch();
        if($u && hash_equals($u['password'],hash('sha256',$_POST['password']))){
            $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'role'=>$u['role']];
            redirect();
        }
        $error='Invalid email or password.';
    }
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fish Rider • Login</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial;background:linear-gradient(135deg,#07152d,#0b4f71);min-height:100vh;display:grid;place-items:center;color:#fff}
.card{width:min(430px,92%);background:rgba(255,255,255,.1);backdrop-filter:blur(18px);padding:38px;border:1px solid rgba(255,255,255,.18);border-radius:24px;box-shadow:0 25px 70px #0005}
.logo{font-size:48px}.brand{font-size:30px;font-weight:800;margin:8px 0}.muted{color:#c7d6e5}.input{width:100%;padding:14px 15px;margin:8px 0 14px;border-radius:12px;border:1px solid #ffffff30;background:#ffffff12;color:white}.input::placeholder{color:#b8c7d5}
.btn{width:100%;padding:14px;border:0;border-radius:12px;background:#20c7a4;color:#06251f;font-weight:800;cursor:pointer}.err{background:#ff4d5f22;border:1px solid #ff6c7a;padding:11px;border-radius:10px;margin-bottom:15px}
</style></head><body><div class="card"><div class="logo">🐟</div><div class="brand">Fish Rider</div><div class="muted">Delivery Management System</div><br>
<?php if(isset($error)) echo '<div class="err">'.h($error).'</div>'; ?>
<form method="post"><input class="input" name="email" type="email" placeholder="Email" required><input class="input" name="password" type="password" placeholder="Password" required><button class="btn" name="login">SIGN IN</button></form>
<p class="muted" style="font-size:13px;margin-top:20px">Admin: admin@fishrider.local / password<br>Rider: rider@fishrider.local / password</p></div></body></html>
<?php exit; }

$page=$_GET['page']??'dashboard';
$action=$_POST['action']??'';

/* Customers */
if($action==='add_customer'){
 $pdo->prepare("INSERT INTO customers(name,phone,address) VALUES(?,?,?)")->execute([$_POST['name'],$_POST['phone'],$_POST['address']]);
 redirect('?page=customers');
}
if($action==='delete_customer'){
 $pdo->prepare("DELETE FROM customers WHERE id=?")->execute([(int)$_POST['id']]); redirect('?page=customers');
}

/* Riders */
if($action==='add_rider'){
 $pdo->prepare("INSERT INTO riders(name,phone,vehicle,status) VALUES(?,?,?,?)")->execute([$_POST['name'],$_POST['phone'],$_POST['vehicle'],$_POST['status']]);
 redirect('?page=riders');
}
if($action==='delete_rider'){
 $pdo->prepare("DELETE FROM riders WHERE id=?")->execute([(int)$_POST['id']]); redirect('?page=riders');
}

/* Orders */
if($action==='add_order'){
 $tracking='FR-'.date('Ymd').'-'.str_pad((string)random_int(1,9999),4,'0',STR_PAD_LEFT);
 do{$q=$pdo->prepare("SELECT id FROM orders WHERE tracking_no=?");$q->execute([$tracking]);}while($q->fetch());
 $pdo->prepare("INSERT INTO orders(tracking_no,customer_id,rider_id,fish_type,quantity,total,payment_status,delivery_status,notes) VALUES(?,?,?,?,?,?,?,?,?)")
 ->execute([$tracking,$_POST['customer_id'],$_POST['rider_id']?:null,$_POST['fish_type'],$_POST['quantity'],$_POST['total'],$_POST['payment_status'],$_POST['delivery_status'],$_POST['notes']]);
 if(!empty($_POST['rider_id'])) $pdo->prepare("UPDATE riders SET status='On Delivery' WHERE id=?")->execute([(int)$_POST['rider_id']]);
 redirect('?page=orders');
}
if($action==='update_status'){
 $pdo->prepare("UPDATE orders SET delivery_status=?,payment_status=?,rider_id=? WHERE id=?")
 ->execute([$_POST['delivery_status'],$_POST['payment_status'],$_POST['rider_id']?:null,(int)$_POST['id']]);
 if(!empty($_POST['rider_id'])) {
   $s=$_POST['delivery_status']==='Delivered'?'Available':'On Delivery';
   $pdo->prepare("UPDATE riders SET status=? WHERE id=?")->execute([$s,(int)$_POST['rider_id']]);
 }
 redirect('?page=orders');
}
if($action==='delete_order'){
 $pdo->prepare("DELETE FROM orders WHERE id=?")->execute([(int)$_POST['id']]); redirect('?page=orders');
}

/* Tracking */
if($page==='track' && isset($_GET['tracking'])){
 $st=$pdo->prepare("SELECT o.*,c.name customer,c.phone,c.address,r.name rider,r.phone rider_phone FROM orders o JOIN customers c ON c.id=o.customer_id LEFT JOIN riders r ON r.id=o.rider_id WHERE o.tracking_no=?");
 $st->execute([$_GET['tracking']]); $track=$st->fetch();
}

$stats=[
 'orders'=>$pdo->query("SELECT COUNT(*) c FROM orders")->fetch()['c'],
 'pending'=>$pdo->query("SELECT COUNT(*) c FROM orders WHERE delivery_status IN ('Pending','Assigned','Picked Up','Out for Delivery')")->fetch()['c'],
 'delivered'=>$pdo->query("SELECT COUNT(*) c FROM orders WHERE delivery_status='Delivered'")->fetch()['c'],
 'revenue'=>$pdo->query("SELECT COALESCE(SUM(total),0) c FROM orders WHERE payment_status='Paid' OR delivery_status='Delivered'")->fetch()['c'],
];
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fish Rider</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial;background:#f4f7fb;color:#142033}.side{position:fixed;width:245px;height:100vh;background:#071b35;color:white;padding:25px 16px}.brand2{font-size:23px;font-weight:900;padding:8px 12px 28px}.nav a{display:block;color:#b9c9da;text-decoration:none;padding:13px 14px;border-radius:11px;margin:5px 0}.nav a:hover,.nav .on{background:#123b62;color:white}.main{margin-left:245px;padding:28px;max-width:1500px}.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:25px}.user{background:white;padding:10px 15px;border-radius:12px}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.stat{background:white;padding:22px;border-radius:18px;box-shadow:0 5px 22px #10233d0b}.num{font-size:29px;font-weight:900;margin-top:8px}.muted{color:#718096}.panel{background:white;border-radius:18px;padding:20px;margin-top:20px;box-shadow:0 5px 22px #10233d0b}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:13px 10px;border-bottom:1px solid #edf1f5;text-align:left;font-size:14px}.badge{display:inline-block;padding:6px 9px;border-radius:20px;background:#e9f2ff;color:#1762a5;font-size:12px;font-weight:700}.btn{border:0;background:#0b76c9;color:white;padding:10px 14px;border-radius:9px;cursor:pointer;font-weight:700}.danger{background:#e84d5b}.form{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.input,.select,.textarea{width:100%;padding:11px;border:1px solid #dce4ee;border-radius:9px;background:white}.textarea{min-height:80px}.full{grid-column:1/-1}.search{padding:11px;border:1px solid #ddd;border-radius:9px}.linkbtn{color:#0b76c9;text-decoration:none;font-weight:700}
@media(max-width:850px){.side{position:relative;width:100%;height:auto}.main{margin:0}.grid{grid-template-columns:repeat(2,1fr)}.form{grid-template-columns:1fr}}@media(max-width:550px){.grid{grid-template-columns:1fr}.main{padding:15px}.top{align-items:flex-start;gap:10px;flex-direction:column}.table{font-size:12px}.panel{overflow:auto}}
</style></head><body>
<aside class="side"><div class="brand2">🐟 FISH RIDER</div><nav class="nav">
<a class="<?= $page==='dashboard'?'on':'' ?>" href="?page=dashboard">📊 Dashboard</a>
<a class="<?= $page==='orders'?'on':'' ?>" href="?page=orders">📦 Orders</a>
<a class="<?= $page==='customers'?'on':'' ?>" href="?page=customers">👥 Customers</a>
<a class="<?= $page==='riders'?'on':'' ?>" href="?page=riders">🏍️ Riders</a>
<a href="?page=track">🔎 Track Delivery</a>
<a href="?logout=1">🚪 Logout</a></nav></aside>
<main class="main"><div class="top"><div><h1 style="margin:0"><?= $page==='dashboard'?'Dashboard':ucfirst($page) ?></h1><span class="muted">Fish delivery operations</span></div><div class="user">👤 <?=h($_SESSION['user']['name'])?></div></div>

<?php if($page==='dashboard'): ?>
<div class="grid"><div class="stat">📦 Orders<div class="num"><?=h($stats['orders'])?></div><span class="muted">All orders</span></div>
<div class="stat">🚚 Active<div class="num"><?=h($stats['pending'])?></div><span class="muted">In delivery</span></div>
<div class="stat">✅ Delivered<div class="num"><?=h($stats['delivered'])?></div><span class="muted">Completed</span></div>
<div class="stat">₱ Revenue<div class="num">₱<?=number_format($stats['revenue'],2)?></div><span class="muted">Paid/completed</span></div></div>
<div class="panel"><h2>Recent Deliveries</h2><table class="table"><tr><th>Tracking</th><th>Customer</th><th>Fish</th><th>Status</th><th>Total</th></tr>
<?php foreach($pdo->query("SELECT o.*,c.name customer FROM orders o JOIN customers c ON c.id=o.customer_id ORDER BY o.id DESC LIMIT 8") as $o): ?>
<tr><td><a class="linkbtn" href="?page=track&tracking=<?=h($o['tracking_no'])?>"><?=h($o['tracking_no'])?></a></td><td><?=h($o['customer'])?></td><td><?=h($o['fish_type'])?></td><td><span class="badge"><?=h($o['delivery_status'])?></span></td><td>₱<?=number_format($o['total'],2)?></td></tr>
<?php endforeach;?></table></div>

<?php elseif($page==='orders'): ?>
<div class="panel"><h2>➕ New Delivery Order</h2><form method="post" class="form">
<input type="hidden" name="action" value="add_order">
<select class="select" name="customer_id" required><option value="">Customer</option><?php foreach($pdo->query("SELECT * FROM customers ORDER BY name") as $c):?><option value="<?=$c['id']?>"><?=h($c['name'])?></option><?php endforeach;?></select>
<select class="select" name="rider_id"><option value="">Assign Rider</option><?php foreach($pdo->query("SELECT * FROM riders ORDER BY name") as $r):?><option value="<?=$r['id']?>"><?=h($r['name'])?> — <?=h($r['status'])?></option><?php endforeach;?></select>
<input class="input" name="fish_type" placeholder="Fish type e.g. Bangus" required><input class="input" name="quantity" type="number" step=".01" placeholder="Quantity" required>
<input class="input" name="total" type="number" step=".01" placeholder="Total amount" required>
<select class="select" name="payment_status"><option>COD</option><option>Pending</option><option>Paid</option></select>
<select class="select" name="delivery_status"><option>Pending</option><option>Assigned</option><option>Picked Up</option><option>Out for Delivery</option></select>
<textarea class="textarea full" name="notes" placeholder="Delivery notes"></textarea><button class="btn full">Create Order</button></form></div>
<div class="panel"><h2>📦 Orders</h2><table class="table"><tr><th>Tracking</th><th>Customer</th><th>Rider</th><th>Fish</th><th>Total</th><th>Status</th><th>Action</th></tr>
<?php $os=$pdo->query("SELECT o.*,c.name customer,r.name rider FROM orders o JOIN customers c ON c.id=o.customer_id LEFT JOIN riders r ON r.id=o.rider_id ORDER BY o.id DESC");foreach($os as $o):?>
<tr><td><a class="linkbtn" href="?page=track&tracking=<?=h($o['tracking_no'])?>"><?=h($o['tracking_no'])?></a></td><td><?=h($o['customer'])?></td><td><?=h($o['rider']??'Unassigned')?></td><td><?=h($o['fish_type'])?></td><td>₱<?=number_format($o['total'],2)?></td><td><span class="badge"><?=h($o['delivery_status'])?></span></td>
<td><form method="post" style="display:flex;gap:5px"><input type="hidden" name="action" value="update_status"><input type="hidden" name="id" value="<?=$o['id']?>">
<select class="select" name="delivery_status"><?php foreach(['Pending','Assigned','Picked Up','Out for Delivery','Delivered','Cancelled'] as $s):?><option <?=$s===$o['delivery_status']?'selected':''?>><?=$s?></option><?php endforeach;?></select>
<select class="select" name="payment_status"><?php foreach(['Pending','COD','Paid'] as $s):?><option <?=$s===$o['payment_status']?'selected':''?>><?=$s?></option><?php endforeach;?></select>
<select class="select" name="rider_id"><option value="">None</option><?php foreach($pdo->query("SELECT * FROM riders") as $r):?><option value="<?=$r['id']?>" <?=$r['id']==$o['rider_id']?'selected':''?>><?=h($r['name'])?></option><?php endforeach;?></select><button class="btn">Save</button></form></td></tr>
<?php endforeach;?></table></div>

<?php elseif($page==='customers'): ?>
<div class="panel"><h2>👥 Add Customer</h2><form method="post" class="form"><input type="hidden" name="action" value="add_customer"><input class="input" name="name" placeholder="Full name" required><input class="input" name="phone" placeholder="Phone"><textarea class="textarea full" name="address" placeholder="Complete address" required></textarea><button class="btn full">Add Customer</button></form></div>
<div class="panel"><h2>Customer List</h2><table class="table"><tr><th>Name</th><th>Phone</th><th>Address</th><th></th></tr><?php foreach($pdo->query("SELECT * FROM customers ORDER BY id DESC") as $c):?><tr><td><?=h($c['name'])?></td><td><?=h($c['phone'])?></td><td><?=h($c['address'])?></td><td><form method="post" onsubmit="return confirm('Delete customer?')"><input type="hidden" name="action" value="delete_customer"><input type="hidden" name="id" value="<?=$c['id']?>"><button class="btn danger">Delete</button></form></td></tr><?php endforeach;?></table></div>

<?php elseif($page==='riders'): ?>
<div class="panel"><h2>🏍️ Add Rider</h2><form method="post" class="form"><input type="hidden" name="action" value="add_rider"><input class="input" name="name" placeholder="Rider name" required><input class="input" name="phone" placeholder="Phone"><input class="input" name="vehicle" placeholder="Vehicle"><select class="select" name="status"><option>Available</option><option>Offline</option><option>On Delivery</option></select><button class="btn full">Add Rider</button></form></div>
<div class="panel"><h2>Rider List</h2><table class="table"><tr><th>Name</th><th>Phone</th><th>Vehicle</th><th>Status</th><th></th></tr><?php foreach($pdo->query("SELECT * FROM riders ORDER BY id DESC") as $r):?><tr><td><?=h($r['name'])?></td><td><?=h($r['phone'])?></td><td><?=h($r['vehicle'])?></td><td><span class="badge"><?=h($r['status'])?></span></td><td><form method="post" onsubmit="return confirm('Delete rider?')"><input type="hidden" name="action" value="delete_rider"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn danger">Delete</button></form></td></tr><?php endforeach;?></table></div>

<?php elseif($page==='track'): ?>
<div class="panel"><h2>🔎 Track Delivery</h2><form method="get" style="display:flex;gap:10px"><input type="hidden" name="page" value="track"><input class="input" name="tracking" value="<?=h($_GET['tracking']??'')?>" placeholder="Enter tracking number e.g. FR-20260928-0001" required><button class="btn">Track</button></form></div>
<?php if(isset($track)): ?><div class="panel"><h2><?=h($track['tracking_no'])?></h2><div class="grid">
<div class="stat"><span class="muted">Customer</span><div class="num" style="font-size:20px"><?=h($track['customer'])?></div><p><?=h($track['phone'])?><br><?=h($track['address'])?></p></div>
<div class="stat"><span class="muted">Rider</span><div class="num" style="font-size:20px"><?=h($track['rider']??'Not assigned')?></div><p><?=h($track['rider_phone']??'')?></p></div>
<div class="stat"><span class="muted">Delivery Status</span><div class="num" style="font-size:20px"><?=h($track['delivery_status'])?></div></div>
<div class="stat"><span class="muted">Amount</span><div class="num" style="font-size:20px">₱<?=number_format($track['total'],2)?></div><p><?=h($track['payment_status'])?></p></div>
</div></div><?php elseif(isset($_GET['tracking'])):?><div class="panel">Tracking number not found.</div><?php endif; ?>
<?php else: ?><div class="panel">Page not found.</div><?php endif; ?>
</main></body></html>
