FISH RIDER DELIVERY SYSTEM
1. Copy folder fish_rider_complete to C:\xampp\htdocs\
2. Start Apache and MySQL.
3. Open phpMyAdmin and import fish_rider.sql.
4. Open http://localhost/fish_rider_complete/
5. Login:
   Admin: admin@fishrider.local / password
   Rider: rider@fishrider.local / password
