CREATE DATABASE IF NOT EXISTS fish_rider CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fish_rider;

DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS riders;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(160) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','rider') NOT NULL DEFAULT 'admin',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE riders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(40),
 vehicle VARCHAR(80),
 status ENUM('Available','On Delivery','Offline') DEFAULT 'Available',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(40),
 address TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tracking_no VARCHAR(40) NOT NULL UNIQUE,
 customer_id INT NOT NULL,
 rider_id INT NULL,
 fish_type VARCHAR(120) NOT NULL,
 quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
 total DECIMAL(12,2) NOT NULL DEFAULT 0,
 payment_status ENUM('Pending','Paid','COD') DEFAULT 'COD',
 delivery_status ENUM('Pending','Assigned','Picked Up','Out for Delivery','Delivered','Cancelled') DEFAULT 'Pending',
 notes TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE,
 FOREIGN KEY(rider_id) REFERENCES riders(id) ON DELETE SET NULL
);

INSERT INTO users(name,email,password,role) VALUES
('Administrator','admin@fishrider.local',SHA2('password',256),'admin'),
('Juan Rider','rider@fishrider.local',SHA2('password',256),'rider');

INSERT INTO riders(name,phone,vehicle,status) VALUES
('Juan Rider','09171234567','Motorcycle','Available'),
('Mark Santos','09987654321','Motorcycle','Offline');

INSERT INTO customers(name,phone,address) VALUES
('Maria Dela Cruz','09180000001','Calapan City, Oriental Mindoro'),
('Pedro Santos','09180000002','Naujan, Oriental Mindoro');

INSERT INTO orders(tracking_no,customer_id,rider_id,fish_type,quantity,total,payment_status,delivery_status,notes) VALUES
('FR-20260928-0001',1,1,'Bangus',3,900,'COD','Out for Delivery','Handle with care'),
('FR-20260928-0002',2,NULL,'Tilapia',5,750,'Pending','Pending','Call customer before delivery');
